import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { User } from '@supabase/supabase-js';
import {
  supabase,
  isSupabaseConfigured,
  assertSupabaseConfigured,
  getTodayPKT,
  getSavedRollNo,
  setSavedRollNo,
  isBootstrappedAdminEmail,
  handleSupabaseError,
  OperationType
} from './supabase';
import { AcademyProfile, UserRole, VALIDATION_LIMITS } from './types';

interface RegisterStudentInput {
  fullName: string;
  phone: string;
  rollNo?: string;
  skill: string;
  email: string;
  password: string;
}

interface AcademyAuthContextValue {
  user: User | null;
  profile: AcademyProfile | null;
  loading: boolean;
  authError: string | null;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  registerStudent: (input: RegisterStudentInput) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signInWithGoogle: (registrationDefaults?: {
    fullName?: string;
    phone?: string;
    rollNo?: string;
    skill?: string;
  }) => Promise<void>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AcademyAuthContext = createContext<AcademyAuthContextValue | undefined>(undefined);

function toIsoString(val: unknown): string {
  if (!val) return new Date().toISOString();
  if (typeof val === 'string') return val;
  if (val instanceof Date) return val.toISOString();
  return new Date().toISOString();
}

function mapRowToProfile(raw: Record<string, any>, fallbackUid: string): AcademyProfile {
  const uid = String(raw.id || fallbackUid);
  const rawRole = String(raw.role || 'student').toLowerCase();
  const normalizedRole: UserRole =
    rawRole === 'admin' || rawRole === 'super_admin' || isBootstrappedAdminEmail(raw.email)
      ? 'admin'
      : 'student';

  const resolvedRollNo = String(raw.roll_no || getSavedRollNo(uid) || '').trim();
  if (resolvedRollNo) {
    setSavedRollNo(uid, resolvedRollNo);
  }

  return {
    id: uid,
    email: String(raw.email || ''),
    full_name: String(raw.full_name || 'Student'),
    phone: String(raw.phone || ''),
    roll_no: resolvedRollNo,
    batch: String(raw.batch || ''),
    role: normalizedRole,
    skill: String(raw.skill || 'Graphic Designing'),
    admission_date: String(raw.admission_date || getTodayPKT()),
    is_approved: raw.is_approved !== false && raw.approval_status !== 'rejected' && raw.approval_status !== 'blocked',
    is_active: raw.is_active !== false && raw.approval_status !== 'blocked',
    created_at: toIsoString(raw.created_at),
    updated_at: toIsoString(raw.updated_at)
  };
}

export function AcademyAuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<AcademyProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const loadOrCreateProfile = useCallback(
    async (
      supaUser: User,
      meta?: {
        fullName?: string;
        phone?: string;
        rollNo?: string;
        skill?: string;
      }
    ): Promise<AcademyProfile> => {
      const uid = supaUser.id;
      const email = (supaUser.email || '').trim().toLowerCase();
      const userMeta = supaUser.user_metadata || {};

      let effectiveMeta = meta;
      if (!effectiveMeta) {
        try {
          const rawOAuthDefaults = sessionStorage.getItem('inspire_academy_oauth_defaults');
          if (rawOAuthDefaults) {
            effectiveMeta = JSON.parse(rawOAuthDefaults);
            sessionStorage.removeItem('inspire_academy_oauth_defaults');
          }
        } catch {
          // ignore storage errors
        }
      }

      if (effectiveMeta?.rollNo) {
        setSavedRollNo(uid, effectiveMeta.rollNo);
      } else if (userMeta.roll_no) {
        setSavedRollNo(uid, String(userMeta.roll_no));
      }

      const isEmailAdmin = isBootstrappedAdminEmail(email);

      let isListedAdmin = isEmailAdmin;
      try {
        const { data: adminRow } = await supabase
          .from('admins')
          .select('uid, email, full_name, roll_no')
          .eq('uid', uid)
          .maybeSingle();

        if (adminRow) {
          isListedAdmin = true;
        } else if (isEmailAdmin) {
          const defaultAdminName =
            email === 'theinspirebusinessacademy@gmail.com'
              ? 'Adeel Bhatti (Admin)'
              : email === 'huzaifaghori4315@gmail.com'
              ? 'Huzaifa Ghori (Admin)'
              : effectiveMeta?.fullName?.trim() || userMeta.full_name || 'Academy Admin';
          const defaultRollNo =
            email === 'theinspirebusinessacademy@gmail.com'
              ? 'ADMIN-01'
              : email === 'huzaifaghori4315@gmail.com'
              ? 'ADMIN-02'
              : 'ADMIN';

          await supabase.from('admins').upsert(
            {
              uid,
              email,
              full_name: defaultAdminName,
              roll_no: defaultRollNo,
              updated_at: new Date().toISOString()
            },
            { onConflict: 'uid' }
          );
          isListedAdmin = true;
        }
      } catch {
        // Ignore if admins table is not yet created; profile query below will surface any schema issue
      }

      const { data: existingProfile, error: selectError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', uid)
        .maybeSingle();

      if (selectError) {
        handleSupabaseError(selectError, OperationType.GET, `profiles/${uid}`);
      }

      if (existingProfile) {
        let finalProfileData = { ...existingProfile };

        const needsAdminUpgrade =
          isListedAdmin &&
          (existingProfile.role !== 'admin' ||
            existingProfile.is_active === false ||
            existingProfile.is_approved === false);

        const needsMetadataUpdate =
          Boolean(effectiveMeta?.fullName && existingProfile.full_name === 'Inspire Student') ||
          Boolean(effectiveMeta?.phone && !existingProfile.phone) ||
          Boolean(effectiveMeta?.rollNo && !existingProfile.roll_no);

        if (needsAdminUpgrade || needsMetadataUpdate) {
          const updates: Record<string, any> = {
            updated_at: new Date().toISOString()
          };
          if (needsAdminUpgrade) {
            updates.role = 'admin';
            updates.approval_status = 'approved';
            updates.is_approved = true;
            updates.is_active = true;
          }
          if (effectiveMeta?.fullName?.trim()) updates.full_name = effectiveMeta.fullName.trim();
          if (effectiveMeta?.phone?.trim()) updates.phone = effectiveMeta.phone.trim();
          if (effectiveMeta?.rollNo?.trim()) updates.roll_no = effectiveMeta.rollNo.trim();
          if (effectiveMeta?.skill?.trim() && !isListedAdmin) updates.skill = effectiveMeta.skill.trim();

          const { data: updatedRow } = await supabase
            .from('profiles')
            .update(updates)
            .eq('id', uid)
            .select('*')
            .maybeSingle();

          if (updatedRow) {
            finalProfileData = updatedRow;
          } else {
            finalProfileData = { ...existingProfile, ...updates };
          }
        }

        return mapRowToProfile(finalProfileData, uid);
      }

      // Create initial profile row if trigger hasn't created it yet
      const defaultName =
        effectiveMeta?.fullName?.trim() ||
        String(userMeta.full_name || userMeta.name || '').trim() ||
        (email === 'theinspirebusinessacademy@gmail.com'
          ? 'Adeel Bhatti (Admin)'
          : email === 'huzaifaghori4315@gmail.com'
          ? 'Huzaifa Ghori (Admin)'
          : email
          ? email.split('@')[0]
          : 'Inspire Student');

      const cleanName = defaultName.slice(0, VALIDATION_LIMITS.FULL_NAME_MAX);
      const cleanPhone = String(effectiveMeta?.phone || userMeta.phone || '')
        .trim()
        .slice(0, VALIDATION_LIMITS.PHONE_MAX);
      const cleanRollNo = String(
        effectiveMeta?.rollNo ||
          userMeta.roll_no ||
          getSavedRollNo(uid) ||
          (email === 'theinspirebusinessacademy@gmail.com'
            ? 'ADMIN-01'
            : email === 'huzaifaghori4315@gmail.com'
            ? 'ADMIN-02'
            : '')
      )
        .trim()
        .slice(0, 40);
      const cleanSkill = (
        isListedAdmin
          ? 'Academy Administration'
          : effectiveMeta?.skill?.trim() || String(userMeta.skill || 'Graphic Designing').trim()
      ).slice(0, VALIDATION_LIMITS.SKILL_MAX);

      const role: UserRole = isListedAdmin ? 'admin' : 'student';
      const todayPKT = getTodayPKT();
      const nowIso = new Date().toISOString();

      const insertPayload = {
        id: uid,
        email,
        full_name: cleanName.length >= 2 ? cleanName : 'Inspire Student',
        phone: cleanPhone,
        roll_no: cleanRollNo,
        role,
        approval_status: 'approved',
        is_approved: true,
        is_active: true,
        skill: cleanSkill,
        admission_date: todayPKT,
        created_at: nowIso,
        updated_at: nowIso
      };

      const { data: insertedRow, error: insertError } = await supabase
        .from('profiles')
        .upsert(insertPayload, { onConflict: 'id' })
        .select('*')
        .maybeSingle();

      if (insertError) {
        handleSupabaseError(insertError, OperationType.CREATE, `profiles/${uid}`);
      }

      return mapRowToProfile(insertedRow || insertPayload, uid);
    },
    []
  );

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    let mounted = true;

    const initSession = async () => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) throw error;
        const sessionUser = data.session?.user ?? null;
        if (!mounted) return;

        if (!sessionUser) {
          setUser(null);
          setProfile(null);
          setLoading(false);
          return;
        }

        setUser(sessionUser);
        const hydrated = await loadOrCreateProfile(sessionUser);
        if (!mounted) return;

        if (!hydrated.is_active) {
          await supabase.auth.signOut();
          setUser(null);
          setProfile(null);
          setAuthError('Your student account is currently disabled. Please contact the Academy Admin.');
        } else {
          setProfile(hydrated);
        }
      } catch (err: any) {
        if (mounted) {
          console.error('Failed to initialize Supabase session:', err);
          setAuthError(err?.message || 'Could not load student profile.');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    initSession();

    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted) return;
      const sessionUser = session?.user ?? null;

      if (!sessionUser || event === 'SIGNED_OUT') {
        setUser(null);
        setProfile(null);
        setLoading(false);
        return;
      }

      setUser(sessionUser);
      try {
        const hydrated = await loadOrCreateProfile(sessionUser);
        if (!mounted) return;
        if (!hydrated.is_active) {
          await supabase.auth.signOut();
          setUser(null);
          setProfile(null);
          setAuthError('Your student account is currently disabled. Please contact the Academy Admin.');
        } else {
          setProfile(hydrated);
        }
      } catch (err: any) {
        console.error('Auth state change profile hydration error:', err);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [loadOrCreateProfile]);

  const signInWithEmail = async (email: string, password: string) => {
    setAuthError(null);
    assertSupabaseConfigured();
    const cleanEmail = email.trim().toLowerCase();

    const { data, error } = await supabase.auth.signInWithPassword({
      email: cleanEmail,
      password
    });

    if (error) {
      const msg = error.message || 'Invalid login credentials.';
      if (msg.toLowerCase().includes('email not confirmed')) {
        const friendly =
          'Email is not confirmed in Supabase yet. Please run supabase/admin_setup.sql in your Supabase SQL Editor to auto-confirm accounts.';
        setAuthError(friendly);
        throw new Error(friendly);
      }
      if (msg.toLowerCase().includes('invalid login credentials')) {
        const isTargetAdmin = isBootstrappedAdminEmail(cleanEmail);
        const friendly = isTargetAdmin
          ? 'Invalid admin email or password. Make sure you have run supabase/admin_setup.sql in your Supabase SQL Editor so both admin accounts and passwords are synced.'
          : 'Invalid email or password. Please check your credentials and try again.';
        setAuthError(friendly);
        throw new Error(friendly);
      }
      setAuthError(msg);
      throw new Error(msg);
    }

    if (!data.user) {
      throw new Error('Authentication failed: no user returned from Supabase.');
    }

    const hydrated = await loadOrCreateProfile(data.user);
    if (!hydrated.is_active) {
      await supabase.auth.signOut();
      setUser(null);
      setProfile(null);
      const disabledMsg = 'Your student account is currently disabled. Please contact the Academy Admin.';
      setAuthError(disabledMsg);
      throw new Error(disabledMsg);
    }

    setUser(data.user);
    setProfile(hydrated);
  };

  const registerStudent = async (input: RegisterStudentInput) => {
    setAuthError(null);
    assertSupabaseConfigured();

    const cleanName = input.fullName.trim();
    const cleanPhone = input.phone.trim();
    const cleanEmail = input.email.trim().toLowerCase();
    const cleanRoll = (input.rollNo || '').trim();

    if (cleanName.length < VALIDATION_LIMITS.FULL_NAME_MIN) {
      throw new Error('Please enter your full name (at least 2 characters).');
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      throw new Error('Please enter a valid email address.');
    }
    if (input.password.length < 6) {
      throw new Error('Password must be at least 6 characters.');
    }

    // Student registration strictly creates student-role accounts only
    const { data, error } = await supabase.auth.signUp({
      email: cleanEmail,
      password: input.password,
      options: {
        data: {
          full_name: cleanName,
          phone: cleanPhone,
          roll_no: cleanRoll,
          skill: input.skill,
          admission_date: getTodayPKT(),
          role: 'student'
        }
      }
    });

    if (error) {
      setAuthError(error.message || 'Registration failed.');
      throw new Error(error.message || 'Registration failed.');
    }

    if (!data.user) {
      throw new Error('Could not create user account.');
    }

    // If Supabase project has email confirmation enabled and didn't return a session yet,
    // attempt immediate signInWithPassword (works automatically if on_auth_user_auto_confirm trigger is installed)
    let activeUser = data.user;
    if (!data.session) {
      const { data: signInData, error: signInErr } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: input.password
      });
      if (signInErr) {
        throw new Error(
          'Account registered! Please check your email to confirm your account, or run supabase/admin_setup.sql in Supabase SQL Editor to enable instant auto-confirmation.'
        );
      }
      if (signInData.user) {
        activeUser = signInData.user;
      }
    }

    const hydrated = await loadOrCreateProfile(activeUser, {
      fullName: cleanName,
      phone: cleanPhone,
      rollNo: cleanRoll,
      skill: input.skill
    });

    setUser(activeUser);
    setProfile(hydrated);
  };

  const resetPassword = async (email: string) => {
    setAuthError(null);
    assertSupabaseConfigured();
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      const msg = 'Please enter a valid email address to receive a password reset link.';
      setAuthError(msg);
      throw new Error(msg);
    }

    const redirectUrl = `${window.location.origin}${window.location.pathname}#/academy/login`;
    const { error } = await supabase.auth.resetPasswordForEmail(cleanEmail, {
      redirectTo: redirectUrl
    });

    if (error) {
      setAuthError(error.message || 'Failed to send password reset email.');
      throw new Error(error.message || 'Failed to send password reset email.');
    }
  };

  const signInWithGoogle = async (registrationDefaults?: {
    fullName?: string;
    phone?: string;
    rollNo?: string;
    skill?: string;
  }) => {
    setAuthError(null);
    assertSupabaseConfigured();

    if (registrationDefaults) {
      try {
        sessionStorage.setItem(
          'inspire_academy_oauth_defaults',
          JSON.stringify(registrationDefaults)
        );
      } catch {
        // ignore storage errors
      }
    }

    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.href
      }
    });

    if (error) {
      setAuthError(error.message || 'Google sign-in failed.');
      throw new Error(error.message || 'Google sign-in failed.');
    }
  };

  const signOut = async () => {
    if (isSupabaseConfigured) {
      await supabase.auth.signOut();
    }
    setUser(null);
    setProfile(null);
    setAuthError(null);
  };

  const refreshProfile = async () => {
    if (!user || !isSupabaseConfigured) return;
    const hydrated = await loadOrCreateProfile(user);
    setProfile(hydrated);
  };

  return (
    <AcademyAuthContext.Provider
      value={{
        user,
        profile,
        loading,
        authError,
        signInWithEmail,
        registerStudent,
        resetPassword,
        signInWithGoogle,
        signOut,
        refreshProfile
      }}
    >
      {children}
    </AcademyAuthContext.Provider>
  );
}

export function useAcademyAuth(): AcademyAuthContextValue {
  const ctx = useContext(AcademyAuthContext);
  if (!ctx) {
    throw new Error('useAcademyAuth must be used inside <AcademyAuthProvider>');
  }
  return ctx;
}
